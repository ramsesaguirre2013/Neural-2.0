<h5 style="font-family: verdana; margin-bottom: 10px;">El Archivo: <strong style="color: red;"><?php echo $NombreArchivo; ?></strong> No Existe.</h5>
<p style="font-family: verdana; font-size: 10px; margin-top: 0px; margin-bottom: 15px;">
	<strong>Modulo:</strong> <?php echo $Modulo; ?><br />
	<strong>Carpeta:</strong> <?php echo $Vistas; ?><br />
	<strong>Archivo:</strong> <?php echo $NombreArchivo; ?><br />
	<strong>Ruta:</strong>	<?php echo $Modulo.$Vistas.$NombreArchivo; ?>
</p>