<h5 style="font-family: verdana; margin-bottom: 10px;">No Exiten Archivos en la Configuraci�n de Vistas.</h5>
<p style="font-family: verdana; font-size: 10px; margin-top: 0px; margin-bottom: 15px;">
	<strong>Modulo:</strong> <?php echo $Modulo; ?><br />
	<strong>Carpeta:</strong> <?php echo $Vistas; ?><br />
	<strong>Archivo:</strong> <?php echo $Archivo; ?>.php<br />
	<strong>Ruta:</strong>	<?php echo $Modulo.$Vistas.$Archivo; ?>.php
</p>