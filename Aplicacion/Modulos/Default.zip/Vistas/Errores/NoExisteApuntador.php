<h5 style="font-family: verdana; margin-bottom: 10px;">No Exite el Tipo de Vista <strong style="color: red;"><?php echo $Tipo; ?></strong>.</h5>
<p style="font-family: verdana; font-size: 10px; margin-top: 0px; margin-bottom: 15px;">
	<strong>Tipo de Vista:</strong> <?php echo $Tipo; ?><br />
	<strong>Modulo:</strong> <?php echo $Modulo; ?><br />
	<strong>Carpeta:</strong> <?php echo $Vistas; ?><br />
	<strong>Archivo:</strong> <?php echo $Archivo; ?>.php<br />
	<strong>Ruta:</strong>	<?php echo $Modulo.$Vistas.$Archivo; ?>.php
</p>